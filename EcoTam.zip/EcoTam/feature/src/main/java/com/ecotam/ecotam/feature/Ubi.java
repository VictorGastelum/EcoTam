package com.ecotam.ecotam.feature;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ubi extends AppCompatActivity {

    private Button buttonC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubi);

        buttonC=findViewById(R.id.button4);
        buttonC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openH();
            }
        });
    }

    public void openH(){
        Intent intent= new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
